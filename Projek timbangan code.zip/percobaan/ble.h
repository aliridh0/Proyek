#include <ArduinoBLE.h>

BLEService bodyWeightService("12345678-1234-5678-1234-56789abcdef0");
BLEStringCharacteristic bodyWeightChar("00000000-0000-0000-0000-000000000001", BLERead | BLENotify, 7);

void init_ble() {
  
  if (!BLE.begin()) {
    Serial.println("Starting BLE failed!");
    while (1);
  }

  BLE.setLocalName("BLE aliiiii");
  BLE.setAdvertisedService(bodyWeightService);

  bodyWeightService.addCharacteristic(bodyWeightChar);

  BLE.addService(bodyWeightService);
  bodyWeightChar.writeValue("0");
  BLE.advertise();

  Serial.println("Bluetooth device active, waiting for connections...");
}
