#include <HX711.h>

// Inisialisasi pin DT (data) dan SCK (clock)
const int LOADCELL_DOUT_PIN = 18;
const int LOADCELL_SCK_PIN = 19;

// Buat objek HX711
HX711 scale;

//variabel
float weight;


void init_loadcell(){
  scale.begin(LOADCELL_DOUT_PIN, LOADCELL_SCK_PIN);
  scale.set_scale(21595);
  scale.tare();
}

void baca_loadcell(){
    //ambil data berat
  float weight = scale.get_units();

  // Tampilkan hasil pembacaan di Serial Monitor
  Serial.print("Berat: ");
  Serial.print(weight);
  Serial.println(" kg");

  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Berat : " + (String)weight + "kg");
}

void sendData() {
  float weight = scale.get_units();
  for (int i=0 ; i<10; i++){
    // Kirim data berat melalui BLE
     bodyWeightChar.writeValue((String)weight + "kg");
     delay(50);
  }
  lcd.setCursor(0,1);
  lcd.println("terkirim");
  delay(1000);
  read_stat = false;
            // State_btn_timbang = digitalRead(btn_timbang);
            //   if (State_btn_timbang == 0) {
            //   }  
}

void tare(){
  scale.tare();
  Serial.println("Tare Done");
  lcd.setCursor(0,1);
  lcd.println("Tare Done");
  delay(1000);
  read_stat = false;
}