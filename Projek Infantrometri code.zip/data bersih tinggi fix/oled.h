#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define OLED_SDA 21    // Pin SDA OLED
#define OLED_SCL 22   // Pin SCL OLED

Adafruit_SSD1306 display(128, 64, &Wire, OLED_SDA, OLED_SCL);

void init_oled(){
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setTextSize(2);
  display.display();
}