#include <NewPing.h>

//pin
const int TRIGGER_PIN = 18;  // Pin untuk trigger sensor HCSR04
const int ECHO_PIN = 19;     // Pin untuk echo sensor HCSR04
const int MAX_DISTANCE = 200; // Ubah sesuai kebutuhan
NewPing sonar(TRIGGER_PIN, ECHO_PIN, MAX_DISTANCE);


//variabel
int wadah = 110;
int distance;
int jarak;

void baca_tinggi_berdiri(){
  delay(50);
  //ambil data tinggi
  unsigned int distance = sonar.ping_cm();
  jarak = distance; 
  if (distance == 0) {
    Serial.println("Jarak terlalu jauh atau tidak valid");
  } else {
    // Tampilkan hasil pembacaan di Serial Monitor
    Serial.print("Tinggi: ");
    Serial.print(distance);
    Serial.println(" cm");    

    display.clearDisplay();
    display.setCursor(0, 0);
    display.print((String)jarak + " cm");
    display.display();
  } 
}

void baca_tinggi_berbaring(){
  //ambil data tinggi
  unsigned int distance = sonar.ping_cm();
  jarak = wadah - distance;
  if (distance == 0) {
    Serial.println("Jarak terlalu jauh atau tidak valid");    
    display.clearDisplay();
    display.setCursor(0, 0);
    display.print("error");
    display.display();  
    } else {
    // Tampilkan hasil pembacaan di Serial Monitor
    Serial.print("Tinggi: ");
    Serial.print(jarak);
    Serial.println(" cm");

    display.clearDisplay();
    display.setCursor(0, 0);
    display.setTextSize(2);
    display.print((String)jarak+" cm");
    display.display();  
  } 
}

void menu(){
  Serial.println("Menu");
  Serial.println("--> Berdiri");
  Serial.println("--> Berbaring");

  display.setTextSize(2);
  display.setCursor(0, 0);
  display.println("A.Berdiri");
  display.setCursor(0, 20);
  display.println("B.Berbaring");
  display.display();    
}

void send_data() {
  unsigned int distance = sonar.ping_cm();
  for (int i=0 ; i<10; i++){
    // Kirim data berat melalui BLE
      bodyHeightChar.writeValue((String)jarak + "cm");
      delay(50);
  }
  Serial.println("Terkirim");
  display.setCursor(0, 20);
  display.setTextSize(2);
  display.println("Terkirim");
  display.display();
  delay(50); 

  display.clearDisplay();
}