#include <ArduinoBLE.h>

BLEService bodyHeightService("12345678-1234-5678-1234-56789abcdef0");
BLEStringCharacteristic bodyHeightChar("00000000-0000-0000-0000-000000000002", BLERead | BLENotify, 7);

void init_ble() {
  
  if (!BLE.begin()) {
    Serial.println("Starting BLE failed!");
    while (1);
  }

  BLE.setLocalName("BLE aliiiii");
  BLE.setAdvertisedService(bodyHeightService);

  bodyHeightService.addCharacteristic(bodyHeightChar);

  BLE.addService(bodyHeightService);
  bodyHeightChar.writeValue("0");
  BLE.advertise();

  Serial.println("Bluetooth device active, waiting for connections...");
}
